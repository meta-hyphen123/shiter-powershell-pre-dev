Author: 4lbH4cker
### Version 3
(![image](https://raw.githubusercontent.com/4lbH4cker/ALHacking/main/alhacking.png)

# Hacking Tools
Tools to help you with ethical hacking, Social media hack, phone info, Gmail attack, phone number attack, user discovery, Webcam Hack

• Powerful DDOS attack tool!!


# Operating System Requirements
works on any of the following operating systems:

• Android (Using the Termux App)

• Linux (Debian Based Systems)

• Unix

# How to Install
* Open the terminal and type `<pkg install git>`
* Then`<git clone https://github.com/4lbH4cker/ALHacking>`
* `<cd ALHacking>`
* `<bash alhack.sh>`


# Warning

We are not responsible for any misuse or damage caused by this program. Use this tool at your own risk!
