#!/bin/ash
python nosqlmap.py
