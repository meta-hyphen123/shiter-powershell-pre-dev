# Hacked
## Introduction:
+ Tool Hacked is a Kali Linux hacking tools installer for Termux and linux system. Tool Hacked was developed for Termux and linux based systems. Using Tool Hacked, you can install almost 1000+ hacking tools in Termux (android) and other Linux based distributions. Tool Hacked is available for Ubuntu and Debian also.
+ Tool Hacked is an installation tool for installing tools. this tool makes it easy for you. so you don't need to type git clone or look for the github repository. You only have to choose the number. which tool you want to install. there are 1000+ tools ready for install

## Advantages:
+ The advantage of installing this tool is that you don't have to search for a tool manually every time you wanna perform a different type of attack you can just use Tool Hacked to suggest you the tools that are suitable for you.
+ Now when you have found your tool you just have to select the tool by typing its Tool number and the Tool will be automatically installed in your Termux and you will instantly able to use it.

## Overview:
+ Tool Hacked generation of Tool Hacked, This tools is a super power, open source, fast, and automatic tools add your favorite github users and download repository via Tool Hacked, add more github users and find another tools via Tool Hacked
+ You can find tools by just using alphabet letters, Like if you will search for 'A' it will show all tool whatever tool starting letter is 'A'
For Examples
* For letter 'A' it will show you tools like this
+ A-Rat
+ Anonimizer
+ AndroidPinCrack
+ automizer
+ aux
+ etc.

## Operating System Requirements:
+ Tool Hacked works on any of the following operating systems:
* Android (Using the Termux App)


## Tested on:
+ Termux


## Installation:
+ Following are the complete installation commands, Enter all commands one by one in your terminal
+ ```apt-get update -y```
+ ```apt-get upgrade -y```
+ ```apt-get install git -y```
+ ```apt-get install python -y```
+ ```apt-get install figlet -y```
+ ```git clone https://github.com/MrHacker-X/Hacked.git/```
+ ```cd Hacked```
+ ```chmod +x *```
+ ```python hacked.py```

## Single line Command:
```
apt-get update -y;apt-get upgrade -y;apt-get install python -y;apt-get install git -y;apt-get install figlet -y;git clone https://github.com/MrHacker-X/Hacked.git/;cd Hacked;chmod +x *;python hacked.py
```

## Some screenshots:
### Main menu
![photo](https://raw.githubusercontent.com/MrHacker-X/Hacked/main/.img/menu.jpg?token=AQW5VDIRK5TSH3BNP6BINN3AZV33M)
### Find tools by alphabetically
![photo](https://raw.githubusercontent.com/MrHacker-X/Hacked/main/.img/alphabet.jpg?token=AQW5VDL4BKINV6XNJBYCBE3AZV74Y)
#### Install all tools in one click
![photo](https://raw.githubusercontent.com/MrHacker-X/Hacked/main/.img/allinstall.jpg?token=AQW5VDML2RMYSPS67A3P7HLAZV766)
### About
![photo](https://raw.githubusercontent.com/MrHacker-X/Hacked/main/.img/about.jpg?token=AQW5VDKUX4DF54CJGVQIL5LAZWAAG)
### Connect with us
![photo](https://raw.githubusercontent.com/MrHacker-X/Hacked/main/.img/follow.jpg?token=AQW5VDLMXDK4OESFODJQSD3AZWAC2)

## Warning:
+ We are not responsible for any misuse or damage caused by this program. use this tool at your own risk!

<h3><b><i>📡 Connect with us :</i></b></h3>
<a href="https://github.com/MrHacker-X/"><img align="left" title="Github" alt="Github" width="30px" src="https://raw.githubusercontent.com/MrHacker-X/MrHacker-X/main/assets/github.png" /></a>
<a href="https://instagram.com/mrhacker.x/"><img align="left" title="Instagram" alt="Instagram" width="30px" src="https://raw.githubusercontent.com/MrHacker-X/MrHacker-X/main/assets/instagram.png" /></a>
<a href="https://t.me/hackwithalex/"><img align="left" title="Telegram" alt="Telegram" width="30px" src="https://raw.githubusercontent.com/MrHacker-X/MrHacker-X/main/assets/telegram.png" /></a>
<a href="https://youtube.com/@Technolex/"><img align="left" title="YouTube" alt="YouTube" width="30px" src="https://raw.githubusercontent.com/MrHacker-X/MrHacker-X/main/assets/youtube.png" /></a>

#
<h3><b><i>🏆 Some popular Repository :</i></b></h3>

<p align="center"><a href="https://github.com/MrHacker-X/SploitX.git/"><img title="SploitX" src="https://github-readme-stats.vercel.app/api/pin/?username=MrHacker-X&repo=SploitX&theme=radical"></a>
<p align="center"><a href="https://github.com/MrHacker-X/CloneWeb.git/"><img title="CloneWeb" src="https://github-readme-stats.vercel.app/api/pin/?username=MrHacker-X&repo=CloneWeb&theme=radical"></a>
<p align="center"><a href="https://github.com/MrHacker-X/termux-fingerprint.git/"><img title="termux-fingerprint" src="https://github-readme-stats.vercel.app/api/pin/?username=MrHacker-X&repo=termux-fingerprint&theme=radical"></a>
