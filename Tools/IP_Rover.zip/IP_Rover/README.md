# IP_Rover
An Excellent OSINT tool to get information of any ip address. All details are explained in below screenshot.

# Service
* For paid hacking service dm me on instagram @coding_memz
* Get 14M passwordlist containing mostly used passwords dm me on instagram @coding_memz

# Tutorial
Read Blog [Here](https://www.cyberdioxide.com/2023/11/ip-location-track-latitude-longitude-of.html)
# Telegram

* Telegram Contact: @coding_memz

  
# Important!

All usage procedures should be performed to not to get any error

# Usage
1. apt install python3
2. git clone https://github.com/Cyber-Dioxide/IP_Rover/
3. cd IP_Rover
4. ls
5. pip install -r requirements.txt
6. python3 finder.py

Enjoy!!!

# Screenshot

In this example i've used random ip, thats why some contents are shown None, I've personally tested on my ip and i've got all the information


![Screenshot (265)](https://user-images.githubusercontent.com/93708296/160673593-c8499850-71f4-4035-b97a-fdd8effebb93.png)
![Screenshot (266)](https://user-images.githubusercontent.com/93708296/160673599-c63c1649-8aa9-485b-81b5-71af336f5159.png)

# Donate
* Paypal: @maazwaheed123

# Support
For any kind of help / support , iam mostly active on instagram and telegram @coding_memz
