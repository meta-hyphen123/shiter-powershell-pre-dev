#include<stdio.h>
#include<stdlib.h>

int main()
{
system("color y8");
system("echo press any key to exit!");
getch();

}