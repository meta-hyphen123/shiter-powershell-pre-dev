# Big-Tool
The big-tool is for installing all hacking and security tools !

This code write by [Mr.nope](https://github.com/msprogrammer2938)

## Scr
[![Big-Tool-Scr](https://user-images.githubusercontent.com/78996423/124370947-e37e3580-dc91-11eb-9068-aa120789155e.jpeg)](https://github.com/mrprogrammer2938/Big-Tool)

Big-Tool tools:
- nmap
- sqlmap
- cewl
- metasploit
- sqlninja
- wifite
- Aircrack-ng

Big-Tool package:
- htop

The install.sh file runs with root !

### run root...
```
sudo su
```

**installing...**
```
git clone https://github.com/mrprogrammer2938/Big-Tool.git

cd Big-Tool

bash install.sh

./tools
```
## update Big-Tool
```
cd Update

./update
```

[![image](https://user-images.githubusercontent.com/78996423/116021528-9c564180-a65d-11eb-8752-8fc25b0394c8.png)](https://github.com/mrprogrammer2938/Big-Tool)

#### run on [Termux](https://wiki.termux.com/wiki/Main_Page)...
[![big-toolontermuxscr](https://user-images.githubusercontent.com/78996423/117602778-c2eca000-b166-11eb-844c-81656d1064a3.jpeg)](https://github.com/mrprogrammer2938/Big-Tool)

## Download [Termux](https://play.google.com/store/apps/details?id=com.termux&hl=en&gl=US)

## [Ms.nope](https://github.com/mrprogrammer2938) Account...
[Instagram](https://instagram.com/programmer2938)

## check New tools...
[DDos-Attack](https://github.com/mrprogrammer2938/DDos-Attack)

### LICENSE
[Mit LICENSE](https://github.com/mrprogrammer2938/Big-Tool/blob/master/LICENSE)
